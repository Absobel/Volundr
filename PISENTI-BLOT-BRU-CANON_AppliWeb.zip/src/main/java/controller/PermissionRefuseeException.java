package controller;

/**
 * PermissionRefuseeException
 */
public class PermissionRefuseeException extends Exception {

  public PermissionRefuseeException(String err) {
    super(err);
  }
}
